#pragma once

#include "dict1.h"
#include <string.h>
#define MAX 129

static int stringCount = 0;
static int charCount = 0;
static int bitCount = 0;
struct NameData 
{
    char trading_name[MAX];
};

struct SortArr
{
    struct NameData* data;
    int size;
};

//初始化排序数组
struct SortArr* InitSortArr();

//遍历字典，依次赋值给数组的函数
void InsertArr(struct SortArr* array, struct Dictionary* dict) ;

// //拷贝数组
// void CopyArray(struct NameData* src, struct NameData* dest, int size); 

// 对数组进行排序
void SortArray(struct SortArr* array);

//进行 find_and_traverse二分查找和线性搜索。并打印结果
void find_and_traverse(struct SortArr* arr, int size, const char* prefix,FILE* outfile);

//打印数组
void Print(struct SortArr* arr);

//释放内存
void FreeArray(struct SortArr* arr);
