
#include "dict2.h"
//初始化排序数组
struct SortArr* InitSortArr()
{
    struct SortArr* s = (struct SortArr*)malloc(sizeof(struct SortArr));
    if(s == NULL)
    {
        printf("申请内存失败");
        return NULL;
    }
    s->data = NULL;
    s->size = 0;
    // printf("初始化成功\n");
    return s;
    
}
//遍历字典，依次赋值给数组的函数
void InsertArr(struct SortArr* array, struct Dictionary* dict) 
{
    struct Data* current = dict->node;
    while (current != NULL) 
    {
        struct NameData* newData = (struct NameData*)malloc(sizeof(struct NameData));
        strcpy(newData->trading_name, current->trading_name);
        array->data = (struct NameData*)realloc(array->data, (array->size + 1) * sizeof(struct NameData));
        array->data[array->size] = *newData;
        array->size++;
        current = current->next;

        free(newData);
    }
    // printf("size:%d\n",array->size);
    // printf("插入成功\n");
}

//比较规则
int compare(const void* a, const void* b)
{
    struct NameData* nameA = (struct NameData*)a;
    struct NameData* nameB = (struct NameData*)b;
    return strcmp(nameA->trading_name, nameB->trading_name);
}

// 对数组进行排序
void SortArray(struct SortArr* array) 
{
    qsort(array->data, array->size, sizeof(struct NameData), compare);
}

//模拟实现C库my_strncmp函数
int my_strncmp(const char* str1, const char* str2, size_t n) 
{
    (stringCount)++;//字符串+1
    size_t i;
    for (i = 0; i < n; i++) 
    {
        //如果不相等
        if (str1[i] != str2[i]) 
        {
            charCount++;//
            if (str1[i] < str2[i])
            {
                return -1;
            }
            else
            {
                return 1;
            }
        }
        if (str1[i] == '\0') 
        {   
            return 0;
        }
        //相等则继续
        charCount++;
    }
    // printf("执行\n");
    charCount++;
    return 0;
}


//Arbory Bar and Eatery , Domino's Pizza
//                        Arbory Bar and Eatery
//0 1  
//二分查找子函数
int binary_search(struct SortArr* arr, int low, int high,const char* prefix) 
{
    int right = high;
    int left = low; 
    while (low <= high) 
    {
        int mid = low + (high - low) / 2;//9 4 1 0
        int comparison = my_strncmp(arr->data[mid].trading_name, prefix, strlen(prefix));//1  2

        if (comparison == 0) 
        {           
            // printf("找到前%d找到了\n", stringCount);
            // 找到匹配项，向前和向后执行线性搜索
            //找到了
            //(stringCount)++;//字符串+1
            //0 1 2 3 4
            //0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19
            //左边
            int i = mid;//1 0 5
            // printf("i是%d\n", i);
            // printf("此时字符串是%s\n",arr->data[i].trading_name);
            while (i > 0 && my_strncmp(arr->data[i-1].trading_name, prefix, strlen(prefix)) == 0) 
            {               
                //  printf("左边相同\n");
                i--;
            }
            // printf("左边%d\n", stringCount);
            //右边
            i = mid;//1 2 3
            // printf("此时右边的字符串是%s\n",arr->data[i+1].trading_name);

            while (i < right && my_strncmp(arr->data[i+1].trading_name, prefix, strlen(prefix)) == 0) 
            {
                //2 3 4
                //  printf("右边相同\n");
                i++;//2 3 4
            }
            // printf("右边%d\n", stringCount);
            
            return 1;
        }
        else if (comparison < 0) 
        {
            low = mid + 1;
        }
        else 
        {
            high = mid - 1;
        }   
    }
    return 0;
}

//进行 find_and_traverse二分查找和线性搜索。并打印结果
void find_and_traverse(struct SortArr* arr, int size, const char* prefix,FILE* outfile) 
{
    stringCount = 0;
    charCount = 0;
    bitCount = 0;
    if (!binary_search(arr, 0, size - 1, prefix)) 
    {
        printf("没有前缀匹配\n");
    }
    //并打印结果
    //Domino's Pizza --> b120 c15 s1

    fprintf(outfile,"%s --> b%d c%d s%d\n",
     prefix, charCount*8, charCount, stringCount);
    
    fflush(outfile);
}

void Print(struct SortArr* arr)
{
    int i = 0;
    for(i = 0; i < arr->size; i++)
    {
        printf("%s\n",arr->data[i].trading_name);
    }
}
// void CopyArray(struct NameData* src, struct NameData* dest, int size) 
// {
//     // Copy the contents of src array to dest array
//     int i = 0;
//     for (i = 0; i < size; i++) {
//         strcpy(dest[i].trading_name, src[i].trading_name);
//     }
// }


//释放内存
void FreeArray(struct SortArr* arr) 
{
    if (arr == NULL)
        return;

  
    
    free(arr->data);
    free(arr);
}



