
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "dict1.h"

void specialCase(char* dest, char* src) 
{
    if (src == NULL) 
    {
        dest[0] = '\0';
        return;
    }

    if (src[0] == '"') 
    {
       
        strncpy(dest, src + 1, 128 - 1);

        while (1) 
        {
            src = strtok(NULL, ",");
            strncat(dest, ",", 128 - strlen(dest) - 1);
            strncat(dest, src, 128 - strlen(dest) - 1);
            if (src[strlen(src) - 1] == '"') 
            {
                dest[strlen(dest) - 1] = '\0'; 
                break;
            }
        }
    } 
    else 
    {
        strncpy(dest, src, 128 - 1);
    }
    dest[128 - 1] = '\0';
}


/**
* Create a Café Dictionary from a data file.
*
* This function reads data from a specified file and constructs a Café Dictionary
* containing information about cafés. Each line in the file represents a café's
* details in CSV format. The function parses the CSV fields and populates the
* dictionary with café records.
*
* param fname The name of the data file to read from.
* return A pointer to the newly created Café Dictionary, or NULL if an error occurs.
*/


// // Implement code to search for records matching key in the cafe dictionary
// // and print the matching records to the out

void WriteDictionary(struct Dictionary* dict, char* key, FILE* out) 
{
    if (dict == NULL || key == NULL || out == NULL) 
    {
        printf("Parameter error");
        return;
    }

    struct Data* cur = dict->node; // Current café information node
    int count = 0; // Number of matched records

    // Iterate through the entire café dictionary
    while (cur != NULL) 
    {
        if (strcmp(cur->trading_name, key) == 0) 
        {
            if (count == 0) {
                // Print the trading name only once
                fprintf(out, "%s\n", cur->trading_name);
            }

            // Print café information to the output file in the desired format
            fprintf(out, "--> census_year: %d || block_id: %d || property_id: %d || base_property_id: %d || building_address: %s || clue_small_area: %s || business_address: %s || trading_name: %s || industry_code: %d || industry_description: %s || seating_type: %s || number_of_seats: %d || longitude: %.5lf || latitude: %.5lf ||\n",
                cur->census_year, cur->block_id, cur->property_id, cur->base_property_id,
                cur->building_address, cur->clue_small_area, cur->business_address,
                cur->trading_name, cur->industry_code, cur->industry_description,
                cur->seating_type, cur->number_of_seats, cur->longitude, cur->latitude);

            count++;
        }

        cur = cur->next;
    }

    // Print the match count and "NOTFOUND" if no matches were found
    printf("%s --> %d\n", key, count);
    if (count == 0) {
        printf("%s --> NOTFOUND\n", key);
    }

    fflush(out);
}


struct Dictionary* InitDictionary(char* fname) 
{
    FILE* fl = fopen(fname, "r");
    if (fl == NULL) 
    {
        printf("Unable to open the file");
        return NULL;
    }

    struct Dictionary* dict = (struct Dictionary*)malloc(sizeof(struct Dictionary));
    if (dict == NULL) 
    {
        printf("Unable to allocate memory");
        fclose(fl);
        return NULL;
    }
    dict->node = NULL;

    struct Data* tail = NULL; // Track the tail of the list
    char line[600];
    fgets(line, sizeof(line), fl); //Skip the nodeer row

    while (fgets(line, sizeof(line), fl) != NULL) 
    {
        struct Data* cafe = (struct Data*)malloc(sizeof(struct Data));
        if (cafe == NULL) 
        {
            printf("Unable to allocate memory");
            fclose(fl);
            FreeDictionary(dict);
            return NULL;
        }

        char* tk = strtok(line, ",");
        if (tk == NULL) {
            printf("Unable to parse CSV field");
            fclose(fl);
            free(cafe);

            FreeDictionary(dict);
            return NULL;
        }
        cafe->census_year = atoi(tk);

        tk = strtok(NULL, ",");
        cafe->block_id = atoi(tk);
        tk = strtok(NULL, ",");
        cafe->property_id = atoi(tk);

        tk = strtok(NULL, ",");
        cafe->base_property_id = atoi(tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->building_address, tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->clue_small_area, tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->business_address, tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->trading_name, tk);

        tk = strtok(NULL, ",");
        cafe->industry_code = atoi(tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->industry_description, tk);

        tk = strtok(NULL, ",");
        specialCase(cafe->seating_type, tk);

        tk = strtok(NULL, ",");
        cafe->number_of_seats = atoi(tk);

        tk = strtok(NULL, ",");
        cafe->longitude = atof(tk);

        tk = strtok(NULL, ",");
        cafe->latitude = atof(tk);
        // Set the next pointer to NULL for the new node    
        cafe->next = NULL; 

        if (tail == NULL) 
        {
            // If the list is empty, set both node and tail to the new node
            dict->node = cafe;
            tail = cafe;
        } 
        else 
        {
            // Otherwise, append the new node after the cur tail and update tail
            tail->next = cafe;
            tail = cafe;
        }
        
    }
    fclose(fl);
    return dict;
}




void FreeDictionary(struct Dictionary* dict) 
{
    if (dict == NULL) {
        return; 
    }

    struct Data* cur = dict->node;
    while (cur != NULL) {
        struct Data* temp = cur;
        cur = cur->next;
        free(temp); // Free memory for café information nodes
    }

    free(dict); // Free memory for dictionary structure
}


