
#pragma once
#include <stdio.h>
#include <stdlib.h>


// Define the data structure for each record
struct Data 
{
    int census_year;
    int block_id;
    int property_id;
    int base_property_id;
    char building_address[200];
    char clue_small_area[200];
    char business_address[200];
    char trading_name[200];
    int industry_code;
    char industry_description[200];
    char seating_type[200];
    int number_of_seats;
    double longitude;
    double latitude;
    struct Data* next;
};

// Define the data structure of the dictionary
struct Dictionary 
{
    struct Data * node;
};


// Search for and print matching café records based on a search key in the provided café dictionary to the specified output file.
void WriteDictionary(struct Dictionary* dict, char* key, FILE* out);
// Free the memory allocated for the café dictionary and its contents.
void FreeDictionary(struct Dictionary* dict);
// Create a café dictionary from a data file.
struct Dictionary* InitDictionary(char* fname);

