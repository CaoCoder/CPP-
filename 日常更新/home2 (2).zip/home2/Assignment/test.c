
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dict1.h"
#include "dict2.h"
/* test.c
*
* This program creates a café dictionary from a data file, accepts user input search keywords,
* and prints the matched café records to an output file.
*
* To run the program:
* ./dict1 <Stage> <Data File> <Output File>
*
* Where:
*   <Stage>         Stage value, this program only accepts a stage value of 1
*   <Data File>     File name containing café data
*   <Output File>   Output file name to store matched café records
* 
*/


int main(int argc, char** argv) 
{
     if (argc != 4 || atoi(argv[1]) != 2)
      {
        printf("Usage %s error\n", argv[0]);
        if (atoi(argv[1]) != 2) 
        {
            printf("\nInvalid stage value\n");
        }
        return 1;
    }
    char* datafile = argv[2];
    char* outputfile = argv[3];
  
// Create a café dictionary from the data file
    struct Dictionary* dict = InitDictionary(datafile);

    if (dict == NULL) 
    {
        printf("Unable to create café dictionary\n");
        return 0;
    }

    //输出的文件
    FILE* outfile = fopen(outputfile, "w");
    if (outfile == NULL) 
    {
        printf("Unable to open output file");
        FreeDictionary(dict);
        return 0;
    }
    
    struct SortArr* arr = InitSortArr();//初始化数组

    InsertArr(arr, dict);//依次插入name数据

    // struct NameData* temp = malloc(arr->size * sizeof(struct NameData));
    // if (temp == NULL) {
    //     printf("内存申请失败\n");
    //     return 1;
    // }
    
    // CopyArray(arr->data, temp, arr->size);

    SortArray(arr);//排序数组
    // Print(arr);

    //依次从std获得字符串
    char sk[129];
    while (1) 
    {
        if (fgets(sk, sizeof(sk), stdin) == NULL) 
        {
            break; 
        }
        sk[strcspn(sk, "\n")] = '\0'; // 去除换行符
        find_and_traverse(arr, arr->size, sk, outfile);//进行二分查找
    }

    
    // // Search and print café records based on user input
    // char sk[129];
    // while (1) 
    // {
    //     if (fgets(sk, sizeof(sk), stdin) == NULL) 
    //     {
    //         break; 
    //     }
    //     sk[strcspn(sk, "\n")] = '\0'; // 去除换行符
    //     WriteDictionary(dict, sk,outfile);
    // }

    //遍历链表把trading_name依次赋值给SortArray
    fclose(outfile);
    // free(temp);
    FreeArray(arr);
    // Free memory allocated for the café dictionary
    FreeDictionary(dict);

    return 0;
}
